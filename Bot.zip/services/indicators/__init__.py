"""Indicator computation services."""
