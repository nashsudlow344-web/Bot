"""Shared schema models for Codex task contracts."""
